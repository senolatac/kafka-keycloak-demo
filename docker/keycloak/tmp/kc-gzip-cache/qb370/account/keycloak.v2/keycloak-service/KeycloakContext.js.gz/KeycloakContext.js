import * as React from "../../keycloak.v2/web_modules/react.js";
export const KeycloakContext = React.createContext(undefined);
//# sourceMappingURL=KeycloakContext.js.map