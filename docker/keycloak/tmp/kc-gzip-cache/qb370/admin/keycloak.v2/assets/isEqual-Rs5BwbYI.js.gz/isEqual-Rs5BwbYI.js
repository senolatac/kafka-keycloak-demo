import{dz as s}from"./index-k_eS9LF7.js";function o(a,r){return s(a,r)}export{o as i};
//# sourceMappingURL=isEqual-Rs5BwbYI.js.map
