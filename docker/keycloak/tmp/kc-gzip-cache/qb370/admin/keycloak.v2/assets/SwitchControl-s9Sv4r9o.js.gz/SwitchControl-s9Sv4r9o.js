import{jsx as r}from"react/jsx-runtime";import{u as a,bq as n}from"./index-k_eS9LF7.js";const l=t=>{const{t:o}=a();return r(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-s9Sv4r9o.js.map
