import{jsx as n}from"react/jsx-runtime";import{forwardRef as e}from"react";import{aM as p}from"./index-k_eS9LF7.js";const m=e(({onChange:o,...r},t)=>n(p,{...r,ref:t,onChange:(f,a)=>o?.(a)}));m.displayName="TextInput";export{m as K};
//# sourceMappingURL=KeycloakTextInput-jXvpqL5y.js.map
