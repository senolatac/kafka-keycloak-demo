import{_ as e,l as o}from"./index-k_eS9LF7.js";import*as l from"react";import{s as m}from"./data-list-CDN1kyj9.js";const i=s=>{var{children:a,className:t=""}=s,r=e(s,["children","className"]);return l.createElement("div",Object.assign({className:o(m.dataListItemControl,t)},r),a)};i.displayName="DataListControl";export{i as D};
//# sourceMappingURL=DataListControl-u5L7sLJ2.js.map
