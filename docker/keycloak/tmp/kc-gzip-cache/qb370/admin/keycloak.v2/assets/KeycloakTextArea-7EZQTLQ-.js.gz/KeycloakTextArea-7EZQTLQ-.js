import{jsx as t}from"react/jsx-runtime";import{forwardRef as n}from"react";import{cX as m}from"./index-k_eS9LF7.js";const s=n(({onChange:r,...o},a)=>t(m,{...o,ref:a,onChange:(p,e)=>r?.(e)}));s.displayName="TextArea";export{s as K};
//# sourceMappingURL=KeycloakTextArea-7EZQTLQ-.js.map
