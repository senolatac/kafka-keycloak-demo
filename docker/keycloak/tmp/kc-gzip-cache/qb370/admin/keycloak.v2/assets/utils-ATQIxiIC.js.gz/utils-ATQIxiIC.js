const t=s=>s?.includes("${"),i=s=>s.substring(2,s.length-1),n=s=>s?.startsWith("lightweight-");export{t as a,n as i,i as u};
//# sourceMappingURL=utils-ATQIxiIC.js.map
