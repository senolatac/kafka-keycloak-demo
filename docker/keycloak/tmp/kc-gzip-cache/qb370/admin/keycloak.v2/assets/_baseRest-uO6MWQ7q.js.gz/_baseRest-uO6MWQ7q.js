import{cV as s,cW as r,cz as o}from"./index-k_eS9LF7.js";function i(t,e){return s(r(t,e,o),t+"")}export{i as b};
//# sourceMappingURL=_baseRest-uO6MWQ7q.js.map
