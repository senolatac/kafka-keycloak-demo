import{M as s}from"./index-k_eS9LF7.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-LAqPLqjP.js.map
